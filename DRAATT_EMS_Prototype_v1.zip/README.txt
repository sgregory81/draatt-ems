DRAATT EMS Narrative Builder — Prototype

IMPORTANT
- TEST / FICTIONAL PATIENT DATA ONLY.
- Not approved for PHI, production clinical use, or direct ePCR integration.
- The QA rules are prototype documentation prompts, not official ADPH determinations.

RUN LOCALLY
1. Unzip this folder.
2. From the folder, run a local web server. Example with Python:
   python -m http.server 8000
3. Open http://localhost:8000 in a browser.

FILES
- index.html: complete clickable prototype
- manifest.json: PWA manifest
- sw.js: basic offline asset cache

CURRENT MODULES
- General Medical
- Chest Pain / ACS
- Respiratory
- Trauma
- Refusal / No Transport
- DRAATT narrative generation
- Prototype QA checks

NEXT PRODUCTION PHASE
- Full ADPH EMSA/stroke module
- Medication/procedure repeatable structured event cards
- OB/delivery, cardiac arrest, sepsis, diabetic/AMS, overdose, IFT/critical care
- Authentication, audit logs, encryption, approved hosting, PHI/HIPAA architecture
- ePCR/NEMSIS mapping/integration
